// Вспомогательные структуры для описания плана рефакторинга
struct RefactoringPlan {
    enum PlanType {
        case extractProtocol
        // TODO: Добавить другие типы рефакторинга
    }

    let type: PlanType
    let targetSCC: [String] // SCC, к которой относится план
    let protocolDetails: ProtocolExtractionDetails?
    // TODO: Добавить другие детали для других типов рефакactoring
}