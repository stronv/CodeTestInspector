//  CohesionService.swift
//  CodeTestInspector
//
//  Created by Artyom Tabachenko on 04.06.2025.
//

import Foundation

/// Детальная информация о сильносвязанной компоненте, включая внутренние зависимости.
struct DetailedSCC {
    let nodes: [String]
    /// Список зависимостей (рёбер) внутри этой SCC.
    /// Каждое ребро представлено кортежем (источник, назначение).
    let internalDependencies: [(source: String, destination: String)]
}