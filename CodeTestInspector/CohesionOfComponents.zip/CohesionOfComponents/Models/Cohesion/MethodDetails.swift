/// Helper struct to store method name and its full signature string.
struct MethodDetails {
    let name: String
    let signature: String // Full signature string, e.g., "func myMethod(param: String) -> Int"
}