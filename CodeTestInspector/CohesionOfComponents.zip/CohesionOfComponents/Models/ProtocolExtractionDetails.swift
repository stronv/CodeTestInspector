import Foundation

struct ProtocolExtractionDetails {
    let name: String // Имя нового протокола
    let methods: [MethodDetails] // Stores MethodDetails with signatures
    let sourceClassName: String // Имя класса, из которого извлекается протокол
    let dependentClassName: String // Имя класса, который зависит от sourceClassName
    let sourceFilePath: String // File path of the source class
    let dependentFilePath: String // <-- Added file path for dependent class
}
