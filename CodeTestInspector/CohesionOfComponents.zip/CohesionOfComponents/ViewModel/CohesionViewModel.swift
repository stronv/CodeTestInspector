//
//  CohesionViewModel.swift
//  CodeTestInspector
//
//  Created by Artyom Tabachenko on 04.06.2025.
//

import Foundation
import SwiftParser
import SwiftUI   // Для DispatchQueue.main.async

final class CohesionViewModel: ObservableObject {
    @Published var cohesionData: CohesionViewData? = nil
    @Published var codeDiff: [DiffLine] = []

    private let service: CohesionServiceProtocol
    private let nameService: NameCollectorService
    private let projectScanner: ProjectScannerProtocol
    private let refactoringCodeGeneratorService: RefactoringCodeGeneratorService
    
    // Чтобы потом записать на диск, храним оба текста:
    private var modifiedSourceCode: String?
    private var modifiedDependentCode: String?
    
    /// URL корневой папки проекта
    private var projectURL: URL?
    /// Security-scoped bookmark для projectURL
    private var projectBookmark: Data?

    init(
        service: CohesionServiceProtocol = CohesionService(),
        nameService: NameCollectorService = NameCollectorService(),
        projectScanner: ProjectScannerProtocol = ProjectScanner(),
        refactoringCodeGeneratorService: RefactoringCodeGeneratorService = RefactoringCodeGeneratorService()
    ) {
        self.service = service
        self.nameService = nameService
        self.projectScanner = projectScanner
        self.refactoringCodeGeneratorService = refactoringCodeGeneratorService
    }
    
    func computeCohesion(for path: URL) {
        
        // Сохраняем projectURL и bookmark
        self.projectURL = path
        if let bookmark = try? path.bookmarkData(
            options: .withSecurityScope,
            includingResourceValuesForKeys: nil,
            relativeTo: nil
        ) {
            self.projectBookmark = bookmark
        }
        
        // 1) Получаем все Swift-файлы в выбранной папке
        let swiftFiles = projectScanner.scan(at: path)

        // 2) Собираем все уникальные имена классов/структур/протоколов
        var allNames: Set<String> = []
        for fileURL in swiftFiles {
            guard let source = try? String(contentsOfFile: fileURL.path, encoding: .utf8) else { continue }
            let tree = Parser.parse(source: source)
            let nameCollector = nameService.makeNameCollector()
            nameCollector.walk(tree)
            allNames.formUnion(nameCollector.names)
        }

        // 3) Вызываем сервис для расчёта SCC и получаем список всех сущностей
        let (cohesionResult, classEntities, methodEntities) = service.computeCohesion(
            for: swiftFiles,
            allNames: allNames
        )

        // 4) На основе рекомендаций строим планы рефакторинга
        var refactoringPlans: [String: RefactoringPlan] = [:]
        for suggestion in cohesionResult.suggestions {
            let key = suggestion.component
                .map { String($0.dropFirst(2)) }      // убираем префиксы C: и M:
                .sorted()
                .joined(separator: ",")
            if let plan = refactoringCodeGeneratorService.planRefactoring(
                for: suggestion,
                classEntities: classEntities,
                methodEntities: methodEntities
            ) {
                refactoringPlans[key] = plan
            }
        }

        // 5) Обновляем Published-свойство, чтобы UI увидел новые данные
        DispatchQueue.main.async {
            self.cohesionData = CohesionViewData(
                allSCCs:       cohesionResult.sccs,
                largeSCCs:     cohesionResult.largeSCCs,
                suggestions:   cohesionResult.suggestions,
                refactoringPlans: refactoringPlans
            )
        }

        // Отладочный вывод
        print("=== computeCohesion completed ===")
        print("All SCCs:        \(cohesionResult.sccs)")
        print("Large SCCs:      \(cohesionResult.largeSCCs)")
        print("Suggestions:     \(cohesionResult.suggestions.count)")
        print("RefactoringPlans:\(refactoringPlans.count)")
    }

    // MARK: - Refactoring Actions
    
    func applyRefactoringPlan(_ plan: RefactoringPlan) {
        guard plan.type == .extractProtocol,
              let details = plan.protocolDetails else { return }

        // 1) читаем оба оригинальных файла
        let srcPath = details.sourceFilePath
        let depPath = details.dependentFilePath
        guard let origSrc = try? String(contentsOfFile: srcPath, encoding: .utf8),
              let origDep = try? String(contentsOfFile: depPath, encoding: .utf8)
        else { return }

        // 2) модифицируем
        let newSrc = refactoringCodeGeneratorService.modifySourceClass(
            originalCode: origSrc,
            plan: plan
        )
        let newDep = refactoringCodeGeneratorService.modifyDependentClass(
            originalDependentCode: origDep,
            plan: plan
        )

        // 3) сохраняем для превью и для записи
        self.modifiedSourceCode    = newSrc
        self.modifiedDependentCode = newDep

        // 4) считаем diff превью для исходника (или для обоих, по желанию)
        if let newSrc = newSrc {
            let origLines = origSrc.components(separatedBy: "\n")
            let modLines  = newSrc.components(separatedBy: "\n")
            self.codeDiff = modLines.diffLines(comparedTo: origLines)
        }
    }
    
    func saveRefactoringChanges() {
        // 1) Достаём детали плана и наши тексты
        guard
            let details = cohesionData?
                .refactoringPlans
                .values
                .first(where: { $0.type == .extractProtocol })?
                .protocolDetails,
            let newSrc = modifiedSourceCode,
            let newDep = modifiedDependentCode,
            let bookmark = projectBookmark
        else {
            print("❌ Нечего сохранять или нет bookmark")
            return
        }

        // 2) Разворачиваем URL из bookmark
        var isStale = false
        guard
            let projURL = try? URL(
                resolvingBookmarkData: bookmark,
                options: .withSecurityScope,
                relativeTo: nil,
                bookmarkDataIsStale: &isStale
            ),
            projURL.startAccessingSecurityScopedResource()
        else {
            print("❌ Не удалось получить access к песочнице")
            return
        }
        defer { projURL.stopAccessingSecurityScopedResource() }

        // 3) Строим относительные пути
        let relSrc = details.sourceFilePath
            .replacingOccurrences(of: projURL.path + "/", with: "")
        let relDep = details.dependentFilePath
            .replacingOccurrences(of: projURL.path + "/", with: "")

        // 4) Полные URL внутри песочницы
        let srcURL = projURL.appendingPathComponent(relSrc)
        let depURL = projURL.appendingPathComponent(relDep)

        // 5) Пишем оба файла
        do {
            try newSrc.write(to: srcURL, atomically: true, encoding: .utf8)
            try newDep.write(to: depURL, atomically: true, encoding: .utf8)
            print("✅ Файлы успешно сохранены:\n  \(srcURL.path)\n  \(depURL.path)")
        } catch {
            print("❌ Ошибка при записи файлов: \(error)")
        }
    }
}

// Модель для отображения diff
struct DiffLine: Identifiable {
    let id = UUID()
    let text: String
    let type: DiffLineType
}

enum DiffLineType {
    case added, removed, unchanged
}

extension Array where Element == String {
    /// Вычисляет diff между self (оригиналом) и other (изменённым).
    func diffLines(comparedTo other: [String]) -> [DiffLine] {
        let diff = self.difference(from: other)
        var result: [DiffLine] = []
        var origIdx = 0, modIdx = 0
        for change in diff {
            switch change {
            case let .remove(offset, element, _):
                while origIdx < offset {
                    result.append(.init(text: self[origIdx], type: .unchanged))
                    origIdx += 1; modIdx += 1
                }
                result.append(.init(text: element, type: .removed))
                origIdx += 1
            case let .insert(offset, element, _):
                while modIdx < offset {
                    if origIdx < self.count {
                        result.append(.init(text: self[origIdx], type: .unchanged))
                        origIdx += 1; modIdx += 1
                    } else { break }
                }
                result.append(.init(text: element, type: .added))
                modIdx += 1
            }
        }
        while origIdx < self.count {
            result.append(.init(text: self[origIdx], type: .unchanged))
            origIdx += 1
        }
        while modIdx < other.count {
            result.append(.init(text: other[modIdx], type: .added))
            modIdx += 1
        }
        return result
    }
}
