// Helper class to add protocol conformance to a specific class declaration.
import SwiftSyntax
import SwiftSyntaxBuilder
import SwiftParser // Although Parser is not directly used in the Rewriter, it might be needed for related tasks or context.

final class ProtocolConformanceRewriter: SyntaxRewriter {
    let targetClassName: String
    let protocolName: String

    init(targetClassName: String, protocolName: String) {
        self.targetClassName = targetClassName
        self.protocolName = protocolName
    }

    override func visit(_ node: ClassDeclSyntax) -> DeclSyntax {
        // Find the target class declaration
        guard node.name.text == targetClassName else {
            return super.visit(node) // Not the target class, continue visiting children
        }

        // Create the InheritedTypeSyntax for the new protocol
        // This node represents just the type conformance itself, without the comma.
        let newInheritedType = InheritedTypeSyntax(
            type: IdentifierTypeSyntax(name: .identifier(protocolName))
        )

        // Check if the class already has an inheritance clause
        if var inheritanceClause = node.inheritanceClause {
            // Add the new protocol to the existing list of inherited types.
            // SwiftSyntax will handle adding the comma and spacing correctly
            // when the list is updated in the InheritanceClauseSyntax.
            var inheritedTypes = inheritanceClause.inheritedTypes
            inheritedTypes.append(newInheritedType) // Append the new type node

            // Update the inheritance clause with the modified list
            inheritanceClause.inheritedTypes = inheritedTypes

            // Update the class declaration with the modified inheritance clause
            let modifiedClassDecl = node.with(\.inheritanceClause, inheritanceClause)
            // Return as DeclSyntax (explicit cast to satisfy the return type)
            return .init(modifiedClassDecl)
        } else {
            // If there is no inheritance clause, create a new one
            let newInheritanceClause = InheritanceClauseSyntax(
                // Add the colon token as part of the new clause
                colon: TokenSyntax(.colon, presence: .present),
                inheritedTypes: InheritedTypeListSyntax {
                    // Add the new inherited type to the new list
                    newInheritedType
                }
            )

            // Update the class declaration with the new inheritance clause
            // No need to set a separate 'colon' property on ClassDeclSyntax
            let modifiedClassDecl = node.with(\.inheritanceClause, newInheritanceClause)

            // Return as DeclSyntax (explicit cast to satisfy the return type)
            return .init(modifiedClassDecl)
        }
    }
}
