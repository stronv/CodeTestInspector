//
//  RefactoringCodeGeneratorService.swift
//  CodeTestInspector
//
//  Created by Artyom Tabachenko on 04.06.2025.
//

import Foundation
import SwiftSyntax
import SwiftParser

final class RefactoringCodeGeneratorService {

    // MARK: — Планирование рефакторинга

    func planRefactoring(
        for suggestion: CohesionSuggestion,
        classEntities: [ClassDependencyEntity],
        methodEntities: [MethodDependencyEntity]
    ) -> RefactoringPlan? {
        // 1) Должно быть ровно две сущности-класса
        guard suggestion.component.count == 2,
              suggestion.component.allSatisfy({ $0.hasPrefix("C:") }),
              let deps = suggestion.involvedDependencies,
              !deps.isEmpty
        else { return nil }

        // 2) Приводим ["C:A","C:B"] → ["A","B"]
        let names = suggestion.component.map { String($0.dropFirst(2)) }
        let class1 = names[0], class2 = names[1]

        // 3) Собираем ребра class1→class2 и class2→class1
        let c1to2 = deps.filter {
            ($0.source.hasPrefix("C:\(class1)") || $0.source.hasPrefix("M:\(class1).")) &&
            ($0.destination.hasPrefix("C:\(class2)") || $0.destination.hasPrefix("M:\(class2)."))
        }
        let c2to1 = deps.filter {
            ($0.source.hasPrefix("C:\(class2)") || $0.source.hasPrefix("M:\(class2).")) &&
            ($0.destination.hasPrefix("C:\(class1)") || $0.destination.hasPrefix("M:\(class1)."))
        }

        // 4) Определяем, кто кандидат на протокол (тот, на который смотрят другие)
        let protocolCandidate: String
        let dependentClass: String
        let forwardDeps: [(source: String, destination: String)]

        if !c1to2.isEmpty {
            protocolCandidate = class2
            dependentClass    = class1
            forwardDeps       = c1to2
        } else if !c2to1.isEmpty {
            protocolCandidate = class1
            dependentClass    = class2
            forwardDeps       = c2to1
        } else {
            return nil
        }

        // 5) Ищем filePath для обоих классов
        guard let protoEntity = classEntities.first(where: { $0.name == protocolCandidate }),
              let depEntity   = classEntities.first(where: { $0.name == dependentClass })
        else {
            return nil
        }
        let sourceFilePath    = protoEntity.filePath
        let dependentFilePath = depEntity.filePath

        // 6) Из ребер фильтруем только методные и получаем имена "bar()"
        var methodNames: [String] = []
        for d in forwardDeps {
            if d.destination.hasPrefix("M:\(protocolCandidate).") {
                let suffix = String(d.destination.dropFirst("M:\(protocolCandidate).".count))
                methodNames.append(suffix) // e.g. "bar()"
            }
        }

        // 7) Извлекаем полные сигнатуры из файла
        var methodDetails: [MethodDetails] = []
        if !methodNames.isEmpty {
            methodDetails = extractMethodSignatures(
                fromFile: sourceFilePath,
                forClass: protocolCandidate,
                methodNames: methodNames
            )
            if methodDetails.count != methodNames.count {
                print("🔴 Не все методы найдены для \(protocolCandidate).")
            }
        }

        // 8) Собираем детали
        let protoName = "\(protocolCandidate)Protocol"
        let details = ProtocolExtractionDetails(
            name: protoName,
            methods: methodDetails,
            sourceClassName: protocolCandidate,
            dependentClassName: dependentClass,
            sourceFilePath: sourceFilePath,
            dependentFilePath: dependentFilePath
        )

        return RefactoringPlan(
            type: .extractProtocol,
            targetSCC: suggestion.component,
            protocolDetails: details
        )
    }

    // MARK: — Генерация кода протокола

    func generateProtocolCode(plan: RefactoringPlan) -> String? {
        guard case .extractProtocol = plan.type,
              let details = plan.protocolDetails
        else { return nil }

        // Создаём наследование ": AnyObject"
        let inheritance = InheritanceClauseSyntax(
            colon: .colonToken(),
            inheritedTypes: InheritedTypeListSyntax {
                InheritedTypeSyntax(
                    typeName: SimpleTypeIdentifierSyntax(name: .identifier("AnyObject"))
                )
            }
        )

        // Построение самого протокола
        let protocolDecl = ProtocolDeclSyntax(
            identifier: .identifier(details.name),
            inheritanceClause: inheritance
        ) {
            // Блок членов протокола: методовые требования
            for method in details.methods {
                if let funcDecl = try? Parser.parse(source: method.signature)
                    .statements.first?.item.as(FunctionDeclSyntax.self)
                {
                    funcDecl
                } else {
                    // На всякий случай, простая заглушка без параметров
                    FunctionDeclSyntax(
                        funcKeyword: .keyword(.func),
                        identifier: .identifier(method.name.replacingOccurrences(of: "()", with: "")),
                        signature: FunctionSignatureSyntax(
                            input: FunctionParameterClauseSyntax(
                                leftParen: .leftParenToken(),
                                parameters: FunctionParameterListSyntax([]),
                                rightParen: .rightParenToken()
                            )
                        )
                    )
                }
            }
        }

        let tree = SourceFileSyntax {
            protocolDecl
        }
        return tree.formatted().description
    }

    // MARK: — Вставка протокола и модификация исходников

    /// 1) Возвращает изменённый текст исходного класса:
    ///    – вставляет protocol <Name> { … } в начало файла,
    ///    – добавляет `: <Name>` после `class <Name>`.
    func modifySourceClass(
        originalCode: String,
        plan: RefactoringPlan
    ) -> String? {
        guard case .extractProtocol = plan.type,
              let details   = plan.protocolDetails,
              let protoCode = generateProtocolCode(plan: plan)
        else {
            return nil
        }

        // Вставляем протокол перед всем остальным кодом
        let withProtocol = protoCode + "\n\n" + originalCode

        // Парсим и добавляем `: ProtocolName` к объявлению класса
        let tree = Parser.parse(source: withProtocol)
        let rewriter = ProtocolConformanceRewriter(
            targetClassName: details.sourceClassName,
            protocolName: details.name
        )
        let modifiedTree = rewriter.rewrite(tree)
        return modifiedTree.formatted().description
    }
    
    /// 2) Возвращает изменённый текст зависимого класса:
    ///    – заменяет все `let x = SourceClass()` на `let x: SourceClassProtocol = SourceClass()`
    func modifyDependentClass(
        originalDependentCode: String,
        plan: RefactoringPlan
    ) -> String? {
        guard case .extractProtocol = plan.type,
              let details = plan.protocolDetails
        else {
            return nil
        }

        let tree = Parser.parse(source: originalDependentCode)
        let rewriter = DependentClassRewriter(
            targetClassName: details.dependentClassName,
            oldTypeName: details.sourceClassName,
            newTypeName: details.name
        )
        let modifiedTree = rewriter.rewrite(tree)
        return modifiedTree.formatted().description
    }

    // MARK: — Извлечение подписей методов (оставляем без изменений)

    private func extractMethodSignatures(
        fromFile filePath: String,
        forClass className: String,
        methodNames: [String]
    ) -> [MethodDetails] {
        guard let source = try? String(contentsOf: URL(fileURLWithPath: filePath), encoding: .utf8) else {
            return []
        }
        let tree = Parser.parse(source: source)
        let extractor = MethodSignatureExtractor(
            targetClassName: className,
            targetMethodNames: Set(methodNames)
        )
        extractor.walk(tree)
        return extractor.extractedMethods.sorted(by: { $0.name < $1.name })
    }
}
